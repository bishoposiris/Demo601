/****==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*X/<()>\X*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==****\
****==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*=/000000\=*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==****
**										                                                                                     **
||  				                                      Socket Library						  				                   ||
**  																																				    **
||  															  Bishop Osiris Minter						 			                   ||
**																																		             **
||																       BasicLib.h    										                ||
**																																						 **
****==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*=\000000/=*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==****
\****==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*X\<()>/X*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==****/

// 4/22/16

// Main header for the basic library

#ifndef BASICLIB_H
#define BASICLIB_H

#include "BasicLibTypes.h"
#include "BasicLibTime.h"
#include "BasicLibString.h"
#include "BasicLibLogger.h"
#include "BasicLibRandom.h"
#include "BasicLibFunctions.h"

#endif
