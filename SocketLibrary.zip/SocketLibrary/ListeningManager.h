/****==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*X/<()>\X*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==****\
****==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*=/000000\=*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==****
**										                                                                                     **
||  				                                      Socket Library						  				                   ||
**  																																				    **
||  															  Bishop Osiris Minter						 			                   ||
**																																		             **
||																   ListeningManager.h 										                ||
**																																						 **
****==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*=\000000/=*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==****
\****==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*X\<()>/X*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==****/

// 4/23/16

// This module contains the listening manager class, which manages incoming connections on a listening socket.

#ifndef LISTENINGMANAGER_H
#define LISTENINGMANAGER_H


// ====================================================================================================================
//  Include Files
// ====================================================================================================================
#include "SocketLibTypes.h"
#include "SocketLibSocket.h"
#include "SocketSet.h"
#include "SocketLibErrors.h"
#include "ConnectionManager.h"
#include <vector>

namespace SocketLib
{
	 // Forward declarations.
	 template<typename protocol, typename defaulthandler>
	 class ConnectionManager;

	 // ================================================================================================================
	 // Description: This is the function that will be used when executing the listening thread
	 // ================================================================================================================

	 // ================================================================================================================
	 // Description: The listening manager class will manage up to 64 listening sockets, monitoring all of them using 
	 // select(). Whenever a new socket is accepted, it is then sent to its accompanying connection manager. 
	 // ================================================================================================================
	 template<typename protocol, typename defaulthandler>
	 class ListeningManager
	 {
	 public:
		  // ============================================================================================================
		  // Description: Construct the manager.
		  // ============================================================================================================
		  ListeningManager();

		  // ============================================================================================================
		  // Description: The destructor should close all of the listening socks.
		  // ============================================================================================================
		  ~ListeningManager();

		  // ============================================================================================================
		  // Description: This adds a port to the manager.
		  // ============================================================================================================
		  void AddPort(port p_port);

		  // ============================================================================================================
		  // Description: This function tells the listening manager about which connection manager it should use whenever 
		  // a new socket is accepted.
		  // ============================================================================================================
		  void SetConnectionManager(ConnectionManager<protocol, defaulthandler>* p_manager);

		  // ============================================================================================================
		  // Description: This listens on the listening sockets for any new connections.
		  // ============================================================================================================
		  void Listen();

	 protected:
		  // This vector contains all of the sockets that the manager will be listening on.
		  std::vector<ListeningSocket> m_sockets;

		  // This is a set of connections that will be used for polling
		  SocketSet m_set;

		  // A pointer to the socket manager that will manage sockets whenever a new socket is accepted.
		  ConnectionManager<protocol, defaulthandler>* m_manager;
	 };

	 // ================================================================================================================
	 // Description: Construct the manager.
	 // ================================================================================================================
	 template<typename protocol, typename defaulthandler>
	 ListeningManager<protocol, defaulthandler>::ListeningManager()
		  {
				m_manager = 0;
		  }


	 // ================================================================================================================
	 // Description: The destructor should close all of the listening socks.
	 // ================================================================================================================
	 template<typename protocol, typename defaulthandler>
	 ListeningManager<protocol, defaulthandler>::~ListeningManager()
		  {
				// just close all the listening sockets.
				for (size_t i = 0; i < m_sockets.size(); i++)
					 {
						  m_sockets[i].Close();
					 }
		  }


	 // ================================================================================================================
	 // Description: This adds a port to the manager.
	 // ================================================================================================================
	 template<typename protocol, typename defaulthandler>
	 void ListeningManager<protocol, defaulthandler>::AddPort(port p_port)
		  {
				if (m_sockets.size() == MAX)
					 {
						  Exception e(ESocketLimitReached);
						  throw(e);
					 }

				// Create a new socket.
				ListeningSocket lsock;

				// Listen on the requested port.
				lsock.Listen(p_port);

				// Make the socket non-blocking, so that it won't block if a connection exploit is used when accepting 
				// (see Chapter 4).
				lsock.SetBlocking(false);

				// Add the socket to the socket vector.
				m_sockets.push_back(lsock);

				// Add the socket descriptor to the set.
				m_set.AddSocket(lsock);
		  }


	 // ================================================================================================================
	 // Description: This function tells the listening manager about which connection manager it should use whenever a 
	 // new socket is accepted.
	 // ================================================================================================================
	 template<typename protocol, typename defaulthandler>
	 void ListeningManager<protocol, defaulthandler>::
		  SetConnectionManager(ConnectionManager<protocol, defaulthandler>* p_manager)
		  {
				// Set the new action function.
				m_manager = p_manager;
		  }


	 template<typename protocol, typename defaulthandler>
	 void ListeningManager<protocol, defaulthandler>::Listen()
	 {
		  // Define a data socket that will receive connections from the listening sockets.
		  DataSocket datasock;

		  // Detect if any sockets have action on them.
		  if (m_set.Poll() > 0)
		  {
				// Loop through every listening socket.
				for (size_t s = 0; s < m_sockets.size(); s++)
				{
					 // Check to see if the current socket has a connection waiting.
					 if (m_set.HasActivity(m_sockets[s]))
					 {
						  try
						  {
								// Accept the connection
								datasock = m_sockets[s].Accept();

								// Run the action function on the new data socket.
								m_manager->NewConnection(datasock);
						  }

						  // Catch any exceptions, and rethrow it if it isn't EWOULDBLOCK. This is done because of a connec-
						  // tion exploit that is possible, by causing a socket to detect a connection, but then not be able 
						  // to retrieve the connection once it gets to the accept call. So, if the connection would block, 
						  // this just ignores it, but if any other error occurs, it is rethrown.
						  catch (Exception& e)
						  {
								if (e.ErrorCode() != EOperationWouldBlock)
								{
									 throw e;
								}
						  }
					 } // End activity check
				} // End socket loop
		  } // End check for number of active sockets
	 }
} // End namespace SocketLib

#endif
